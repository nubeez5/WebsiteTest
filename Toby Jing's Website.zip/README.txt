Run 'Index.html' in the 'Website' folder.
I wrote most of it in 'Visual Studio Code'.
If something doesn't work then tell me.