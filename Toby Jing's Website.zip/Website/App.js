function GoToHomePage() {
	window.location.href = "/Home/Index.html"
}

function GoToAboutPage() {
	window.location.href = "/About/Index.html"
}

function GoToContactPage() {
	window.location.href = "/Contact/Index.html"
}

// Sections
function GoToWhatIsProgrammingPage() {
	window.location.href = "/Sections/Introduction/What-Is-Programming/Index.html"
}

function GoToChoosingALanguagePage() {
	window.location.href = "/Sections/Introduction/Choosing-A-Language/Index.html"
}

function GoToDataTypesPage() {
	window.location.href = "/Sections/Unit-1/Data-Types/Index.html"
}

function GoToOperationsPage() {
	window.location.href = "/Sections/Unit-1/Operations/Index.html"
}